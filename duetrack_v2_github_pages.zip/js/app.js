(() => {
  const STORAGE_KEY = "duetrack_v2_data";
  const DEFAULT = {
    transactions: [],
    reminders: [],
    settings: { currency: "INR", lead: 7 }
  };

  const currencySymbols = { INR: "₹", USD: "$", EUR: "€", GBP: "£" };
  const incomeCategories = ["Salary","Business","Freelance","Allowance","Refund","Other"];
  const expenseCategories = ["Food","Groceries","Transport","Shopping","Bills","Health","Education","Entertainment","EMI","Rent","Other"];
  let data = loadData();
  let calendarDate = new Date();
  let deferredPrompt = null;

  const $ = (id) => document.getElementById(id);
  const $$ = (sel) => [...document.querySelectorAll(sel)];

  function loadData() {
    try {
      const raw = JSON.parse(localStorage.getItem(STORAGE_KEY));
      return raw ? { ...DEFAULT, ...raw, settings: {...DEFAULT.settings, ...(raw.settings || {})} } : structuredClone(DEFAULT);
    } catch { return structuredClone(DEFAULT); }
  }
  function saveData() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    renderAll();
  }
  function money(n=0) {
    const symbol = currencySymbols[data.settings.currency] || "₹";
    return symbol + Math.round(Number(n || 0)).toLocaleString("en-IN");
  }
  function iso(d) {
    const x = new Date(d);
    return x.toISOString().split("T")[0];
  }
  function todayISO() { return iso(new Date()); }
  function parseDate(s) {
    const [y,m,d] = s.split("-").map(Number);
    return new Date(y,m-1,d);
  }
  function dateText(s) {
    return parseDate(s).toLocaleDateString("en-IN", {day:"numeric",month:"short",year:"numeric"});
  }
  function dayDiff(date) {
    const a = new Date(); a.setHours(0,0,0,0);
    const b = parseDate(date); b.setHours(0,0,0,0);
    return Math.round((b-a)/86400000);
  }
  function id() { return crypto?.randomUUID?.() || Date.now().toString(36)+Math.random().toString(36).slice(2); }
  function monthKey(d) { return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}`; }

  function showView(name) {
    $$(".view").forEach(v => v.classList.remove("active"));
    $(name+"View")?.classList.add("active");
    $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
    const titles = {dashboard:"Overview",transactions:"Transactions",reminders:"Reminders",calendar:"Money Calendar",insights:"Insights",settings:"Settings"};
    $("pageTitle").textContent = titles[name] || "DueTrack";
    $("sidebar").classList.remove("open");
  }

  function totals() {
    const income = data.transactions.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
    const expense = data.transactions.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
    const now = new Date();
    const mk = monthKey(now);
    const monthTx = data.transactions.filter(t=>t.date.startsWith(mk));
    const mi = monthTx.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
    const me = monthTx.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
    const due30 = data.reminders.filter(r=>{ const d=dayDiff(r.date); return !r.paid && d>=0 && d<=30; }).reduce((s,r)=>s+r.amount,0);
    return {income,expense,balance:income-expense,mi,me,saved:mi-me,due30,safe:income-expense-due30};
  }

  function renderDashboard() {
    const t = totals();
    $("balanceMetric").textContent = money(t.balance);
    $("reservedMetric").textContent = money(t.due30);
    $("safeMetric").textContent = money(t.safe);
    $("heroSafe").textContent = Math.round(t.safe).toLocaleString("en-IN");
    $("heroDueCount").textContent = data.reminders.filter(r=>!r.paid && dayDiff(r.date)>=0 && dayDiff(r.date)<=30).length;
    $("savedMetric").textContent = money(t.saved);
    const rate = t.mi ? Math.round((t.saved/t.mi)*100) : 0;
    $("savedRate").textContent = `${rate}% savings rate`;
    $("monthHealth").textContent = t.mi===0 ? "No data yet" : t.saved>=0 ? "On track" : "Spending above income";

    const upcoming = data.reminders.filter(r=>!r.paid && dayDiff(r.date)>=-30).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,5);
    $("upcomingList").innerHTML = upcoming.length ? upcoming.map(r => {
      const d = dayDiff(r.date);
      return `<div class="list-item">
        <div class="item-icon">◷</div>
        <div class="item-main"><strong>${escapeHtml(r.name)}</strong><span>${d<0?`${Math.abs(d)} days overdue`:d===0?"Due today":`Due in ${d} day${d===1?"":"s"}`}</span></div>
        <div class="item-amount">${money(r.amount)}</div>
      </div>`;
    }).join("") : `<div class="empty-state">Nothing due soon. Add a reminder to plan ahead.</div>`;

    const recent = [...data.transactions].sort((a,b)=>b.date.localeCompare(a.date) || b.created-b.created).slice(0,5);
    $("recentTransactions").innerHTML = recent.length ? recent.map(t => `
      <div class="list-item">
        <div class="item-icon">${t.type==="income"?"＋":"−"}</div>
        <div class="item-main"><strong>${escapeHtml(t.description)}</strong><span>${escapeHtml(t.category)} · ${dateText(t.date)}</span></div>
        <div class="item-amount ${t.type==="income"?"positive":"negative"}">${t.type==="income"?"+":"−"}${money(t.amount)}</div>
      </div>`).join("") : `<div class="empty-state">No transactions yet.</div>`;

    if (!data.transactions.length && !data.reminders.length) {
      $("moneyCoachTitle").textContent = "Plan first. Spend calmly.";
      $("moneyCoachText").textContent = "Add your income and upcoming payments. DueTrack will calculate what is actually safe to spend.";
    } else if (t.safe < 0) {
      $("moneyCoachTitle").textContent = "Upcoming dues need attention";
      $("moneyCoachText").textContent = `Your planned dues are higher than your current free balance by ${money(Math.abs(t.safe))}. Review upcoming payments before extra spending.`;
    } else {
      $("moneyCoachTitle").textContent = `${money(t.safe)} is currently free`;
      $("moneyCoachText").textContent = `After setting aside ${money(t.due30)} for the next 30 days, this is your estimated safe-to-spend amount.`;
    }
    drawFlowChart();
  }

  function renderTransactions() {
    const filter = $("transactionFilter").value;
    const q = $("transactionSearch").value.trim().toLowerCase();
    let tx = [...data.transactions].sort((a,b)=>b.date.localeCompare(a.date) || b.created-a.created);
    if (filter !== "all") tx = tx.filter(t=>t.type===filter);
    if (q) tx = tx.filter(t=>`${t.description} ${t.category}`.toLowerCase().includes(q));
    if (!tx.length) {
      $("transactionsTable").innerHTML = `<div class="empty-state">No matching transactions.</div>`;
      return;
    }
    $("transactionsTable").innerHTML = `<table><thead><tr><th>Description</th><th>Category</th><th>Date</th><th>Type</th><th>Amount</th><th></th></tr></thead><tbody>` +
      tx.map(t=>`<tr>
        <td><strong>${escapeHtml(t.description)}</strong></td>
        <td>${escapeHtml(t.category)}</td>
        <td>${dateText(t.date)}</td>
        <td class="${t.type==="income"?"positive":"negative"}">${t.type}</td>
        <td><strong>${t.type==="income"?"+":"−"}${money(t.amount)}</strong></td>
        <td class="row-actions"><button data-delete-tx="${t.id}">Delete</button></td>
      </tr>`).join("") + `</tbody></table>`;
  }

  function renderReminders() {
    const active = [...data.reminders].sort((a,b)=>a.date.localeCompare(b.date));
    const sum = n => active.filter(r=>!r.paid && dayDiff(r.date)>=0 && dayDiff(r.date)<=n).reduce((s,r)=>s+r.amount,0);
    $("due7Metric").textContent = money(sum(7));
    $("due30Metric").textContent = money(sum(30));
    $("overdueMetric").textContent = money(active.filter(r=>!r.paid && dayDiff(r.date)<0).reduce((s,r)=>s+r.amount,0));

    $("remindersList").innerHTML = active.length ? active.map(r=>{
      const d = dayDiff(r.date);
      const chip = r.paid ? "Paid" : d<0 ? `${Math.abs(d)} days overdue` : d===0 ? "Due today" : `Due in ${d} day${d===1?"":"s"}`;
      return `<article class="reminder-card">
        <div class="reminder-card-top">
          <div><h4>${escapeHtml(r.name)}</h4><p>${escapeHtml(r.category)} · ${dateText(r.date)}${r.repeat!=="none"?` · ${r.repeat}`:""}</p></div>
          <div class="reminder-amount">${money(r.amount)}</div>
        </div>
        <span class="due-chip ${d<0&&!r.paid?"overdue":""}">${chip}</span>
        ${r.note?`<p style="margin-top:10px">${escapeHtml(r.note)}</p>`:""}
        <div class="reminder-actions">
          ${!r.paid?`<button class="paid" data-paid="${r.id}">✓ Mark paid</button>`:""}
          <button data-edit-reminder="${r.id}">Edit</button>
          <button data-delete-reminder="${r.id}">Delete</button>
        </div>
      </article>`;
    }).join("") : `<div class="empty-state">No reminders yet. Add an EMI, bill or any payment you don't want to forget.</div>`;
  }

  function renderCalendar() {
    const y = calendarDate.getFullYear(), m = calendarDate.getMonth();
    $("calendarMonthTitle").textContent = new Date(y,m,1).toLocaleDateString("en-IN",{month:"long",year:"numeric"});
    const first = new Date(y,m,1), start = new Date(y,m,1-first.getDay());
    const today = todayISO();
    let html = "";
    for (let i=0;i<42;i++) {
      const d = new Date(start); d.setDate(start.getDate()+i);
      const ds = iso(d);
      const dues = data.reminders.filter(r=>r.date===ds && !r.paid);
      html += `<div class="calendar-cell ${d.getMonth()!==m?"muted":""} ${ds===today?"today":""}">
        <span class="day-number">${d.getDate()}</span>
        ${dues.slice(0,3).map(r=>`<span class="calendar-due">${escapeHtml(r.name)} · ${money(r.amount)}</span>`).join("")}
      </div>`;
    }
    $("calendarGrid").innerHTML = html;
  }

  function renderInsights() {
    const now = new Date(), mk = monthKey(now);
    const tx = data.transactions.filter(t=>t.date.startsWith(mk));
    const income = tx.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0);
    const expense = tx.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0);
    const saved = income-expense;
    const rate = income ? Math.round(saved/income*100) : 0;
    $("insightIncome").textContent = money(income);
    $("insightExpense").textContent = money(expense);
    $("insightSavingsRate").textContent = `${rate}%`;
    const cats = {};
    tx.filter(t=>t.type==="expense").forEach(t=>cats[t.category]=(cats[t.category]||0)+t.amount);
    const sorted = Object.entries(cats).sort((a,b)=>b[1]-a[1]);
    $("topCategory").textContent = sorted[0]?.[0] || "—";
    const max = sorted[0]?.[1] || 1;
    $("categoryBreakdown").innerHTML = sorted.length ? sorted.map(([name,value])=>`
      <div class="category-row"><strong>${escapeHtml(name)}</strong><div class="category-bar"><i style="width:${Math.max(4,value/max*100)}%"></i></div><span>${money(value)}</span></div>`).join("") : `<div class="empty-state">No spending this month.</div>`;
    drawTrendChart();
  }

  function renderSettings() {
    $("currencySetting").value = data.settings.currency;
    $("leadSetting").value = String(data.settings.lead);
    $("reminderLead").value = String(data.settings.lead);
  }

  function renderAll() {
    $("todayLabel").textContent = new Date().toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long"});
    renderDashboard(); renderTransactions(); renderReminders(); renderCalendar(); renderInsights(); renderSettings();
    checkDueAlerts();
  }

  function drawBars(canvas, labels, income, expense) {
    const ctx = canvas.getContext("2d");
    const dpr = devicePixelRatio || 1;
    const cssW = canvas.clientWidth || 700, cssH = Math.max(230, Math.round(cssW*.36));
    canvas.width = cssW*dpr; canvas.height = cssH*dpr; ctx.scale(dpr,dpr);
    const w=cssW,h=cssH,pad={l:42,r:16,t:18,b:38}, cw=w-pad.l-pad.r, ch=h-pad.t-pad.b;
    ctx.clearRect(0,0,w,h);
    const max = Math.max(1,...income,...expense);
    ctx.font="10px Inter"; ctx.fillStyle="#8a95a8"; ctx.textAlign="right";
    for(let i=0;i<=4;i++){
      const y=pad.t+ch*(i/4), v=max*(1-i/4);
      ctx.strokeStyle="#edf0f5"; ctx.beginPath(); ctx.moveTo(pad.l,y); ctx.lineTo(w-pad.r,y); ctx.stroke();
      ctx.fillText(shortMoney(v),pad.l-8,y+3);
    }
    const groupW=cw/labels.length, barW=Math.min(15,groupW*.22);
    labels.forEach((lab,i)=>{
      const x=pad.l+i*groupW+groupW/2;
      const ih=income[i]/max*ch, eh=expense[i]/max*ch;
      roundRect(ctx,x-barW-2,pad.t+ch-ih,barW,ih,5,"#635bff");
      roundRect(ctx,x+2,pad.t+ch-eh,barW,eh,5,"#c7c3ff");
      ctx.fillStyle="#8a95a8"; ctx.textAlign="center"; ctx.fillText(lab,x,h-14);
    });
  }
  function roundRect(ctx,x,y,w,h,r,fill){
    if(h<=0)return;
    ctx.fillStyle=fill; ctx.beginPath();
    const rr=Math.min(r,w/2,h/2);
    ctx.moveTo(x+rr,y);ctx.arcTo(x+w,y,x+w,y+h,rr);ctx.arcTo(x+w,y+h,x,y+h,rr);ctx.arcTo(x,y+h,x,y,rr);ctx.arcTo(x,y,x+w,y,rr);ctx.fill();
  }
  function shortMoney(v) {
    const s = currencySymbols[data.settings.currency] || "₹";
    if(v>=100000) return s+(v/100000).toFixed(v>=1000000?0:1)+"L";
    if(v>=1000) return s+Math.round(v/1000)+"k";
    return s+Math.round(v);
  }
  function drawFlowChart() {
    const now = new Date(), labels=[], inc=[], exp=[];
    for(let i=5;i>=0;i--){
      const d=new Date(now.getFullYear(),now.getMonth()-i,1), key=monthKey(d);
      labels.push(d.toLocaleDateString("en-IN",{month:"short"}));
      const tx=data.transactions.filter(t=>t.date.startsWith(key));
      inc.push(tx.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0));
      exp.push(tx.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0));
    }
    drawBars($("flowChart"),labels,inc,exp);
  }
  function drawTrendChart(){ drawFlowChartInto($("trendChart")); }
  function drawFlowChartInto(canvas){
    const now=new Date(),labels=[],inc=[],exp=[];
    for(let i=5;i>=0;i--){
      const d=new Date(now.getFullYear(),now.getMonth()-i,1), key=monthKey(d);
      labels.push(d.toLocaleDateString("en-IN",{month:"short"}));
      const tx=data.transactions.filter(t=>t.date.startsWith(key));
      inc.push(tx.filter(t=>t.type==="income").reduce((s,t)=>s+t.amount,0));
      exp.push(tx.filter(t=>t.type==="expense").reduce((s,t)=>s+t.amount,0));
    }
    drawBars(canvas,labels,inc,exp);
  }

  function openModal(modal) {
    $("backdrop").classList.remove("hidden");
    modal.showModal();
  }
  function closeModals() {
    $$("dialog[open]").forEach(d=>d.close());
    $("backdrop").classList.add("hidden");
  }
  function setEntryCategories(type) {
    const cats = type==="income" ? incomeCategories : expenseCategories;
    $("entryCategory").innerHTML = cats.map(c=>`<option>${c}</option>`).join("");
  }
  function openEntry() {
    $("entryForm").reset();
    $("entryDate").value=todayISO();
    $("entryType").value="expense";
    $$("#transactionTypeSegment button").forEach(b=>b.classList.toggle("active",b.dataset.type==="expense"));
    setEntryCategories("expense");
    openModal($("entryModal"));
  }
  function openReminder(r=null) {
    $("reminderForm").reset();
    $("reminderModalTitle").textContent = r ? "Edit reminder" : "New reminder";
    $("reminderId").value = r?.id || "";
    $("reminderName").value = r?.name || "";
    $("reminderAmount").value = r?.amount ?? "";
    $("reminderDate").value = r?.date || todayISO();
    $("reminderCategory").value = r?.category || "EMI";
    $("reminderRepeat").value = r?.repeat || "none";
    $("reminderLead").value = String(r?.lead ?? data.settings.lead);
    $("reminderNote").value = r?.note || "";
    openModal($("reminderModal"));
  }

  function markPaid(reminder) {
    if (reminder.paid) return;
    data.transactions.push({
      id:id(), type:"expense", amount:Number(reminder.amount), date:todayISO(),
      category:reminder.category || "Bills", description:reminder.name, created:Date.now()
    });
    if (reminder.repeat === "monthly") {
      const d=parseDate(reminder.date); d.setMonth(d.getMonth()+1); reminder.date=iso(d); reminder.paid=false;
    } else if (reminder.repeat === "yearly") {
      const d=parseDate(reminder.date); d.setFullYear(d.getFullYear()+1); reminder.date=iso(d); reminder.paid=false;
    } else reminder.paid=true;
    toast("Payment recorded and expense added.");
    saveData();
  }

  function checkDueAlerts() {
    const due = data.reminders.filter(r=>!r.paid && dayDiff(r.date)>=0 && dayDiff(r.date)<=Number(r.lead||data.settings.lead));
    const signature = due.map(r=>r.id+":"+r.date).join("|");
    if (!due.length || localStorage.getItem("duetrack_alert_signature")===signature) return;
    localStorage.setItem("duetrack_alert_signature", signature);
    if ("Notification" in window && Notification.permission==="granted") {
      const r=due[0];
      new Notification(`${r.name} is coming up`, { body: `${money(r.amount)} due ${dateText(r.date)}. Open DueTrack to review your plan.`, icon:"./assets/icon.svg" });
    }
  }
  function toast(msg) {
    const el=$("toast"); el.textContent=msg; el.classList.remove("hidden");
    clearTimeout(toast.t); toast.t=setTimeout(()=>el.classList.add("hidden"),2800);
  }
  function escapeHtml(s="") {
    return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));
  }

  $$(".nav-item").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.view)));
  $$("[data-jump]").forEach(b=>b.addEventListener("click",()=>showView(b.dataset.jump)));
  $$("[data-view-link]").forEach(a=>a.addEventListener("click",e=>{e.preventDefault();showView(a.dataset.viewLink)}));
  $("mobileMenuBtn").addEventListener("click",()=>{$("sidebar").classList.add("open"); $("backdrop").classList.remove("hidden");});
  $("backdrop").addEventListener("click",()=>{ $("sidebar").classList.remove("open"); closeModals(); });
  $("quickAddBtn").addEventListener("click",openEntry);
  $("addTransactionBtn").addEventListener("click",openEntry);
  $("addReminderBtn").addEventListener("click",()=>openReminder());
  $$(".modal-close").forEach(b=>b.addEventListener("click",closeModals));

  $$("#transactionTypeSegment button").forEach(b=>b.addEventListener("click",()=>{
    $("entryType").value=b.dataset.type;
    $$("#transactionTypeSegment button").forEach(x=>x.classList.toggle("active",x===b));
    setEntryCategories(b.dataset.type);
  }));

  $("entryForm").addEventListener("submit",e=>{
    e.preventDefault();
    data.transactions.push({
      id:id(), type:$("entryType").value, amount:Number($("entryAmount").value),
      date:$("entryDate").value, category:$("entryCategory").value,
      description:$("entryDescription").value.trim(), created:Date.now()
    });
    closeModals(); saveData(); toast("Transaction saved.");
  });

  $("reminderForm").addEventListener("submit",e=>{
    e.preventDefault();
    const rid=$("reminderId").value;
    const payload = {
      id:rid||id(), name:$("reminderName").value.trim(), amount:Number($("reminderAmount").value),
      date:$("reminderDate").value, category:$("reminderCategory").value,
      repeat:$("reminderRepeat").value, lead:Number($("reminderLead").value),
      note:$("reminderNote").value.trim(), paid:false, created:Date.now()
    };
    if(rid){
      const i=data.reminders.findIndex(r=>r.id===rid);
      if(i>=0) data.reminders[i]={...data.reminders[i],...payload};
    } else data.reminders.push(payload);
    closeModals(); saveData(); toast("Reminder saved.");
  });

  document.addEventListener("click",e=>{
    const tx=e.target.closest("[data-delete-tx]");
    if(tx && confirm("Delete this transaction?")){
      data.transactions=data.transactions.filter(t=>t.id!==tx.dataset.deleteTx); saveData(); return;
    }
    const paid=e.target.closest("[data-paid]");
    if(paid){ const r=data.reminders.find(x=>x.id===paid.dataset.paid); if(r) markPaid(r); return; }
    const edit=e.target.closest("[data-edit-reminder]");
    if(edit){ const r=data.reminders.find(x=>x.id===edit.dataset.editReminder); if(r) openReminder(r); return; }
    const del=e.target.closest("[data-delete-reminder]");
    if(del && confirm("Delete this reminder?")){
      data.reminders=data.reminders.filter(r=>r.id!==del.dataset.deleteReminder); saveData(); return;
    }
  });

  $("transactionFilter").addEventListener("change",renderTransactions);
  $("transactionSearch").addEventListener("input",renderTransactions);
  $("prevMonth").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()-1);renderCalendar()});
  $("nextMonth").addEventListener("click",()=>{calendarDate.setMonth(calendarDate.getMonth()+1);renderCalendar()});
  $("currencySetting").addEventListener("change",()=>{data.settings.currency=$("currencySetting").value;saveData()});
  $("leadSetting").addEventListener("change",()=>{data.settings.lead=Number($("leadSetting").value);saveData()});

  $("notifyBtn").addEventListener("click",async()=>{
    if(!("Notification" in window)){toast("Browser notifications are not supported here.");return;}
    const p=await Notification.requestPermission();
    toast(p==="granted"?"Alerts enabled for this browser.":"Notification permission was not enabled.");
    if(p==="granted") checkDueAlerts();
  });

  $("exportBtn").addEventListener("click",()=>{
    const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
    const a=document.createElement("a"); a.href=URL.createObjectURL(blob); a.download=`duetrack-backup-${todayISO()}.json`; a.click(); URL.revokeObjectURL(a.href);
  });
  $("importInput").addEventListener("change",async e=>{
    const file=e.target.files[0]; if(!file)return;
    try { const parsed=JSON.parse(await file.text()); data={...DEFAULT,...parsed,settings:{...DEFAULT.settings,...(parsed.settings||{})}}; saveData(); toast("Backup restored."); }
    catch { toast("That backup file could not be read."); }
    e.target.value="";
  });
  $("clearDataBtn").addEventListener("click",()=>{
    if(confirm("Delete all DueTrack data stored in this browser?")){
      data=structuredClone(DEFAULT); localStorage.removeItem(STORAGE_KEY); renderAll(); toast("Local data deleted.");
    }
  });

  $("demoBtn").addEventListener("click",()=>{
    const now=new Date();
    const d=(offset)=>{const x=new Date();x.setDate(x.getDate()+offset);return iso(x)};
    const mdate=(monthsAgo,day)=>iso(new Date(now.getFullYear(),now.getMonth()-monthsAgo,day));
    data.transactions=[
      {id:id(),type:"income",amount:42000,date:mdate(0,1),category:"Salary",description:"Monthly salary",created:1},
      {id:id(),type:"expense",amount:6500,date:mdate(0,3),category:"Groceries",description:"Monthly groceries",created:2},
      {id:id(),type:"expense",amount:2100,date:mdate(0,7),category:"Transport",description:"Fuel and travel",created:3},
      {id:id(),type:"expense",amount:3200,date:mdate(0,11),category:"Bills",description:"Home bills",created:4},
      {id:id(),type:"income",amount:40000,date:mdate(1,1),category:"Salary",description:"Monthly salary",created:5},
      {id:id(),type:"expense",amount:19200,date:mdate(1,15),category:"Other",description:"Monthly spending",created:6},
      {id:id(),type:"income",amount:40000,date:mdate(2,1),category:"Salary",description:"Monthly salary",created:7},
      {id:id(),type:"expense",amount:21800,date:mdate(2,15),category:"Other",description:"Monthly spending",created:8}
    ];
    data.reminders=[
      {id:id(),name:"Bike EMI",amount:4500,date:d(5),category:"EMI",repeat:"monthly",lead:7,note:"Keep balance ready before auto-debit.",paid:false},
      {id:id(),name:"Electricity bill",amount:1650,date:d(9),category:"Electricity",repeat:"monthly",lead:3,note:"",paid:false},
      {id:id(),name:"Internet",amount:799,date:d(15),category:"Internet",repeat:"monthly",lead:3,note:"",paid:false}
    ];
    saveData(); showView("dashboard"); toast("Demo data loaded.");
  });

  window.addEventListener("resize",()=>{drawFlowChart();drawTrendChart()});
  window.addEventListener("beforeinstallprompt",e=>{e.preventDefault();deferredPrompt=e;$("installBtn").classList.remove("hidden")});
  $("installBtn").addEventListener("click",async()=>{if(!deferredPrompt)return;deferredPrompt.prompt();await deferredPrompt.userChoice;deferredPrompt=null;$("installBtn").classList.add("hidden")});

  if ("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js").catch(()=>{});
  setEntryCategories("expense");
  renderAll();
})();